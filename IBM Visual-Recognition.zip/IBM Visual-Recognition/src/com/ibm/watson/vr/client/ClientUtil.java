package com.ibm.watson.vr.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.ibm.watson.developer_cloud.http.Response;
import com.ibm.watson.developer_cloud.service.security.IamOptions;
import com.ibm.watson.developer_cloud.visual_recognition.v3.VisualRecognition;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassResult;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifiedImage;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifiedImages;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifierResult;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifyOptions;
public class ClientUtil {
	
	String setEndPoint="https://gateway.watsonplatform.net/visual-recognition/api";
	String apiKey="jFQq1gMx1bLjZQ-N3VkzAgKbR6f564sFULRcT30ZbX5v";
	String filePath;
	String fileName;
	String VisualRecognitionId="2018-03-19";
    
    public File[] getFileList() {
    	
    	File directory = new File(getFilePath());
    	File[] fList = directory.listFiles();
		return fList;
    }
	
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public ClassifiedImages callService() throws FileNotFoundException {
		
		VisualRecognition service = new VisualRecognition(VisualRecognitionId);
 		service.setEndPoint(setEndPoint);
        
 		IamOptions options = new IamOptions.Builder().apiKey(apiKey).build();
 		service.setIamCredentials(options);
 		String path=getFilePath()+getFileName().toString();
 		InputStream imagesStream = new FileInputStream(path);
 		System.out.println("VisualRecognitionId-->"+VisualRecognitionId);
 		System.out.println("setEndPoint-->"+setEndPoint);
 		System.out.println("apiKey-->"+apiKey);
 		System.out.println("path-->"+path);
 		ClassifyOptions classifyOptions = new ClassifyOptions.Builder().imagesFile(imagesStream).imagesFilename(getFileName()).threshold((float) 0.6).classifierIds(Arrays.asList("VisualRecognitionnew_941639523")).build();
 	     //ClassifiedImages result = service.classify(classifyOptions).execute();
 	    Response<ClassifiedImages> result1 = service.classify(classifyOptions).executeWithDetails();
 	//	com.ibm.watson.developer_cloud.http.Headers responseHeaders = result1.getHeaders();	
 	   // System.out.println(result1);
 		return result1.getResult();
 		
 		
 		
	}
	
	 public static HashMap<String, String> parseImageClassData(ClassifiedImages data) {
		 HashMap<String, String> map = new HashMap<>();
	        if (data != null) {
	            if (data.getImages().size() > 0) {
	                for (ClassifierResult classifier : data.getImages().get(0).getClassifiers()) {
	                    for (ClassResult clas : classifier.getClasses()) {
	                        //listClass.add(new Class(clas.getClassName(), clas.getScore()));
	                    	// Class class1 = new Class(clas.getClassName(), clas.getScore());
	                    	//listClass.a
	                    	
	                    	map.put(clas.getClassName().toString(), clas.getScore().toString());
	 
	                    	//System.out.println("Class---->"+clas.getClassName());
	                    	//System.out.println("Score---->"+clas.getScore());
	                    	
	                    	System.out.println("Class---->"+map);
	                    	//map.clear();
	                    }
	                }
	            }
	        }
	      return map;
	    }
	
	

}
