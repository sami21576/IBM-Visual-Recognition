/**
 * 
 */
package com.git.wp.bean;

import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * @author SA319424
 *
 */
public class SRJsonParser {

	/**
	 * 
	 */
	public SRJsonParser() {
		// TODO Auto-generated constructor stub
	}

//	public static void main(String a[]) {
//
//		SRJsonParser par = new SRJsonParser();
//		String result = "{\"CreateMXSRResponse\":{\"rsStart\":0,\"rsCount\":1,\"rsTotal\":1,\"MXSRSet\":{\"SR\":{\"rowstamp\":\"1467026\",\"Attributes\":{\"ACTLABCOST\":{\"content\":0.0},\"ACTLABHRS\":{\"content\":0.0},\"CHANGEBY\":{\"content\":\"MAXIMO\"},\"CHANGEDATE\":{\"content\":\"2018-07-30T07:14:19-04:00\"},\"CLASS\":{\"content\":\"SR\"},\"CREATEWOMULTI\":{\"content\":\"MULTI\"},\"HASACTIVITY\":{\"content\":false},\"HASSOLUTION\":{\"content\":false},\"HISTORYFLAG\":{\"content\":false},\"INHERITSTATUS\":{\"content\":true},\"ISGLOBAL\":{\"content\":false},\"ISKNOWNERROR\":{\"content\":false},\"RELATEDTOGLOBAL\":{\"content\":false},\"REPORTDATE\":{\"content\":\"2018-07-30T07:14:19-04:00\"},\"SELFSERVSOLACCESS\":{\"content\":true},\"SITEVISIT\":{\"content\":false},\"STATUS\":{\"content\":\"NEW\"},\"STATUSDATE\":{\"content\":\"2018-07-30T07:14:19-04:00\"},\"TEMPLATE\":{\"content\":false},\"TICKETID\":{\"content\":\"1233\"},\"TICKETUID\":{\"content\":406,\"resourceid\":true}}}}}}";
//
//		try {
//			par.callParser(result);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}

	public SRResultBean callParser(String result) throws ParseException {


		JSONObject jo = getDetails(result);

		SRResultBean bean = new SRResultBean();
		Map srMap = ((Map) jo.get("CreateMXSRResponse"));
		// iterating address Map
		Iterator<Map.Entry> itr1 = srMap.entrySet().iterator();

		while (itr1.hasNext())
		{
			Map.Entry pair = itr1.next();
			// System.out.println(pair.getKey() + " : " + pair.getValue());
			if (pair.getKey().equals("MXSRSet"))
			{
				System.out.println("-------Child-1 Attribute--------------");
				System.out.println("                                      ");
				System.out.println("                                      ");


				System.out.println("MXSRSet --->" + pair.getValue());
				JSONObject mxSrSet = getDetails(pair.getValue().toString());
				System.out.println("                                      ");
				System.out.println("                                      ");

				System.out.println("-------Child-2 Attribute--------------");
				System.out.println("                                      ");
			

				System.out.println("SR --->" + mxSrSet.get("SR"));
				JSONObject mxSr = getDetails(mxSrSet.get("SR").toString());
				System.out.println("                                      ");
				System.out.println("                                      ");

				System.out.println("-------Child-3 Attribute--------------");
				System.out.println("                                      ");
				System.out.println("                                      ");
				

				System.out.println("SR Attribute --->" + mxSr.get("Attributes"));
				System.out.println("                                      ");
				System.out.println("                                      ");


				JSONObject srAttribute = getDetails(mxSr.get("Attributes").toString());
				
				System.out.println("-------Child-4 Attribute--------------");
				System.out.println("                                      ");
				System.out.println("                                      ");


				System.out.println("TICKETID -->" + this.getDetails(srAttribute.get("TICKETID").toString()).get("content"));
				System.out.println("CHANGEDATE -->" + this.getDetails(srAttribute.get("CHANGEDATE").toString()).get("content"));
				System.out.println("CHANGEBY -->" + this.getDetails(srAttribute.get("CHANGEBY").toString()).get("content"));
				System.out.println("STATUS -->" + this.getDetails(srAttribute.get("STATUS").toString()).get("content"));
				System.out.println("CLASS -->" + this.getDetails(srAttribute.get("CLASS").toString()).get("content"));

				bean.setTicketId(this.getDetails(srAttribute.get("TICKETID").toString()).get("content").toString());
				bean.setChangeBy(this.getDetails(srAttribute.get("CHANGEBY").toString()).get("content").toString());
				bean.setChangeDate(this.getDetails(srAttribute.get("CHANGEDATE").toString()).get("content").toString());
				bean.setClassId(this.getDetails(srAttribute.get("CLASS").toString()).get("content").toString());
				bean.setStatus(this.getDetails(srAttribute.get("STATUS").toString()).get("content").toString());
			}
		}
		
		return bean;

	}

	public JSONObject getDetails(String str) throws ParseException {
		Object parserObj = new JSONParser().parse(str);
		JSONObject jsonObject = (JSONObject) parserObj;
		return jsonObject;
	}

}
