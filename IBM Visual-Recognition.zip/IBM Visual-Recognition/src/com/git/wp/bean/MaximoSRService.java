package com.git.wp.bean;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.simple.JSONValue;

public class MaximoSRService {
	
     final String SERVICE_URL = "https://maximo-demo76.mro.com/maxrest/rest/os/MXSR?_lid=maximo&_lpwd=times1";
	//final String SERVICE_URL = "https://maximo-demo76.mro.com/oslc/os/MXSR?_lid=maximo&_lpwd=times1";
	InputStream inputStream = null;

    
	public static String convertStreamToString(InputStream is) throws Exception 
	{
		
	    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
	    StringBuilder sb = new StringBuilder();
	    String line = null;
	    while ((line = reader.readLine()) != null) {
	      sb.append(line + "\n");
	    }
	    is.close();
	    return sb.toString();
	 }
	
	public String serviceCall(Map<String, String> obj) throws ClientProtocolException, IOException {
		
		String json = "";
		String result="";
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(SERVICE_URL);
        
        //  convert JSONObject to JSON to String
        json=JSONValue.toJSONString(obj);  
        
        //  set json to StringEntity
        StringEntity se = new StringEntity(json);
        // set httpPost Entity
        httpPost.setEntity(se);
     // inform the server about the type of the content   
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
        httpPost.setHeader("Content-type", "properties/*");
        
        //  Execute POST request to the given URL
        HttpResponse httpResponse = httpclient.execute(httpPost);

        // receive response as inputStream
        inputStream = httpResponse.getEntity().getContent();
        try {
               if(inputStream != null)
				result = convertStreamToString(inputStream);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        return result;
	}
	

}
