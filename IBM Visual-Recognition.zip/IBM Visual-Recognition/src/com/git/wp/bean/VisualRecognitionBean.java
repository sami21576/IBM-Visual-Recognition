package com.git.wp.bean;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

public class VisualRecognitionBean {
	
	String setEndPoint;
	String apiKey;
	String filePath;
	String VisualRecognitionId;
	static Logger logger;
    
	public VisualRecognitionBean() {
		logger = Logger.getLogger("VisualRecognitionBean()");
		logger.info("Process Start...");
	}
	public void intilaize() throws IOException{
		
		logger.info("Start --> intilaize()");
		
		Properties prop = new Properties();
		InputStream input = null;
		input = new FileInputStream("D:\\eclipse-workspace\\IBM Visual-Recognition\\WebContent\\config.properties");
		prop.load(input);
		
		logger.info(prop.getProperty("setEndPoint"));
		logger.info(prop.getProperty("apiKey"));
		logger.info(prop.getProperty("filePath"));
		logger.info(prop.getProperty("VisualRecognitionId"));
		
		setSetEndPoint(prop.getProperty("setEndPoint"));
		setApiKey(prop.getProperty("apiKey"));
		setFilePath(prop.getProperty("filePath"));
		setVisualRecognitionId(prop.getProperty("VisualRecognitionId"));
		logger.info("End -->intilaize()");
	}
	
	public String getSetEndPoint() {
		return setEndPoint;
	}
	public void setSetEndPoint(String setEndPoint) {
		this.setEndPoint = setEndPoint;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getVisualRecognitionId() {
		return VisualRecognitionId;
	}
	public void setVisualRecognitionId(String visualRecognitionId) {
		VisualRecognitionId = visualRecognitionId;
	}
	

}
