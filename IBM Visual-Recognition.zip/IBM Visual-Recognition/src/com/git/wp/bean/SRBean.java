package com.git.wp.bean;

public class SRBean {
	
	String assetNum;
	String affectedPerson;
	String status;
	String description;
	String reporteDate;
	String reporteBy;
	
	public String getAssetNum() {
		return assetNum;
	}
	public void setAssetNum(String assetNum) {
		this.assetNum = assetNum;
	}
	public String getAffectedPerson() {
		return affectedPerson;
	}
	public void setAffectedPerson(String affectedPerson) {
		this.affectedPerson = affectedPerson;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getReporteDate() {
		return reporteDate;
	}
	public void setReporteDate(String reporteDate) {
		this.reporteDate = reporteDate;
	}
	public String getReporteBy() {
		return reporteBy;
	}
	public void setReporteBy(String reporteBy) {
		this.reporteBy = reporteBy;
	}
	@Override
	public String toString() {
		return "SRBean [assetNum=" + assetNum + ", affectedPerson=" + affectedPerson + ", status=" + status
				+ ", description=" + description + ", reporteDate=" + reporteDate + ", reporteBy=" + reporteBy
				+ ", getAssetNum()=" + getAssetNum() + ", getAffectedPerson()=" + getAffectedPerson() + ", getStatus()="
				+ getStatus() + ", getDescription()=" + getDescription() + ", getReporteDate()=" + getReporteDate()
				+ ", getReporteBy()=" + getReporteBy() + "]";
	}
	

}
