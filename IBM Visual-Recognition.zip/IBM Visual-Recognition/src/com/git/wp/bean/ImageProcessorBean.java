package com.git.wp.bean;

import java.util.Date;

public class ImageProcessorBean {
	
	String className;
	String score;
	String fileName;
	String imgePath;
	Date date;
	boolean flag=false;
	
	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getImgePath() {
		return imgePath;
	}

	public void setImgePath(String imgePath) {
		this.imgePath = imgePath;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	
	public void data(String name, String sc, String file,String path,Date date){

//		className=name;
//		score=sc;
//		fileName=file;
//		imgePath=path;
//		date= new Date();
		setClassName(name);
		setScore(sc);
		setFileName(file);
		setImgePath(path);
		setDate(date);
		setFlag(true);
    }

	@Override
	public String toString() {
		return "ImageProcessorBean [className=" + className + ", score=" + score + ", fileName=" + fileName
				+ ", imgePath=" + imgePath + ", date=" + date + "]";
	}

	
	
}
