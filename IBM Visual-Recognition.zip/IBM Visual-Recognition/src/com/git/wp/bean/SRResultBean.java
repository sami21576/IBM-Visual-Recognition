package com.git.wp.bean;

import java.util.Date;

public class SRResultBean {
	
	String ticketId;
	String status;
	String changeDate;
	String changeBy;
	String statusDate;
	String classId;
	
	public SRResultBean() {
		// TODO Auto-generated constructor stub
	}
    
	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(String string) {
		this.changeDate = string;
	}

	public String getChangeBy() {
		return changeBy;
	}

	public void setChangeBy(String changeBy) {
		this.changeBy = changeBy;
	}

	public String getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	

}
