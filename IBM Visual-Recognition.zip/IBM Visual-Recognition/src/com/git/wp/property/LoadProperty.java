package com.git.wp.property;

import java.io.IOException;
import java.util.logging.Logger;

import com.git.wp.bean.VisualRecognitionBean;

public class LoadProperty {

	public static void main(String[] args) {
		Logger logger = Logger.getLogger("LoadProperty");;
		logger.info("LoadProperty.class");
		VisualRecognitionBean bean= new VisualRecognitionBean();
		try {
			bean.intilaize();
			logger.info(bean.getApiKey());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Properties prop = new Properties();
//		InputStream input = null;
//
//		try {
//
//			input = new FileInputStream("config.properties");
//
//			// load a properties file
//			prop.load(input);
//
//			// get the property value and print it out
//			System.out.println(prop.getProperty("setEndPoint"));
//			System.out.println(prop.getProperty("apiKey"));
//			System.out.println(prop.getProperty("filePath"));
//			System.out.println(prop.getProperty("VisualRecognitionId"));
//
//		} catch (IOException ex) {
//			ex.printStackTrace();
//		} finally {
//			if (input != null) {
//				try {
//					input.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}

	}

}
