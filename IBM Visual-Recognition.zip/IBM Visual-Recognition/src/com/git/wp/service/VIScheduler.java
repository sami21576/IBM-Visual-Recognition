package com.git.wp.service;

import java.io.File;
import java.util.ArrayList;

import com.git.wp.bean.ImageProcessorBean;
import com.git.wp.bean.VisualRecognitionBean;
 
public class VIScheduler {
	
	public static void printResult(VisualRecognitionService service) {
		
		ArrayList<ImageProcessorBean> list = service.getImageInfo();
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).toString());
		}
	}
	public static void main(String[] args) {
 
//		try {
// 
//			SchedulerFactory sf = new StdSchedulerFactory();
//			Scheduler scheduler = sf.getScheduler();
// 
//			JobDetail job = JobBuilder.newJob(VisualRecognitionService.class)
//					.withIdentity("dummyJobName", "group1").build();
// 
//			Date startTime = DateBuilder.nextGivenSecondDate(null, 10);
// 
//			// run 10 seconds only 4 times infinite loop
//			SimpleTrigger simpletrigger = TriggerBuilder
//					.newTrigger()
//					.withIdentity("FourTimesTrigger", "group1")
//					.startAt(startTime)
//					// startNow()
//					.withSchedule(SimpleScheduleBuilder.simpleSchedule()
//					.withIntervalInSeconds(10)
//					.withRepeatCount(1)).build();
// 
//							
// 
//			scheduler.start();
//			scheduler.scheduleJob(job, simpletrigger);
// 
//			// scheduler.shutdown();
// 
//		} catch (SchedulerException se) {
//			se.printStackTrace();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
 
		
		VisualRecognitionBean bean= new VisualRecognitionBean();
		VisualRecognitionService service = new VisualRecognitionService();
		try {
			System.out.println("App Schedular Trigger Starts.."+"intilaize()");	
			bean.intilaize();
			String setEndPoint=bean.getSetEndPoint();
			String apiKey=bean.getApiKey();
			String filePath=bean.getFilePath();
			String VisualRecognitionId=bean.getVisualRecognitionId();
			
			File directory = new File(filePath);
			System.out.println("directory-->"+directory);
			
	    	File[] fList = directory.listFiles();
	    	System.out.println("App Schedular Trigger Starts.."+"Service Call Start...");
	    
	        for (File file : fList) {
	        	   if (file.isFile()) {
										String fileName=file.getName();
										//service.callService(setEndPoint, apiKey, filePath, VisualRecognitionId, fileName);
										System.out.println("setEndPoint-->"+setEndPoint);
										System.out.println("apiKey-->"+apiKey);
										System.out.println("filePath-->"+filePath);
										System.out.println("VisualRecognitionId-->"+VisualRecognitionId);
										System.out.println("fileName-->"+fileName);
										service.callService(setEndPoint, apiKey, filePath, VisualRecognitionId, fileName);
	        	   }
	        }
	        printResult(service);
	        System.out.println("App Schedular Trigger Starts.."+"Service End...");
	     }catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}