package com.git.wp.service;

public interface ILatch {
	void countDown();
}
