package com.git.wp.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Logger;

import com.git.wp.bean.ImageProcessorBean;
import com.ibm.watson.developer_cloud.http.Response;
import com.ibm.watson.developer_cloud.service.security.IamOptions;
import com.ibm.watson.developer_cloud.visual_recognition.v3.VisualRecognition;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassResult;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifiedImages;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifierResult;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifyOptions;

public class VisualRecognitionService {

	static Logger logger;
	String setEndPoint;
	String apiKey;
	String filePath;
	String VisualRecognitionId;
	ArrayList<ImageProcessorBean> imageInfo = new ArrayList<ImageProcessorBean>();

	public ArrayList<ImageProcessorBean> getImageInfo() {
		return imageInfo;
	}

	public VisualRecognitionService() {
		logger = Logger.getLogger("VisualRecognitionService()");
		logger.info("Process Start...");
	}

	public void callService(String setEndPoint, String apiKey, String filePath, String VisualRecognitionId,
			String fileName) throws FileNotFoundException {

		VisualRecognition service = new VisualRecognition(VisualRecognitionId);

		service.setEndPoint(setEndPoint);
		IamOptions options = new IamOptions.Builder().apiKey(apiKey).build();
		service.setIamCredentials(options);
		String path = filePath + fileName.toString();
		InputStream imagesStream = new FileInputStream(path);
		ClassifyOptions classifyOptions = new ClassifyOptions.Builder().imagesFile(imagesStream)
				.imagesFilename(fileName).threshold((float) 0.6)
				.classifierIds(Arrays.asList("VisualRecognitionnew_941639523")).build();
		Response<ClassifiedImages> result = service.classify(classifyOptions).executeWithDetails();
		ClassifiedImages data = result.getResult();

		if (data != null) {
			if (data.getImages().size() > 0) {
				for (ClassifierResult classifier : data.getImages().get(0).getClassifiers()) {
					for (ClassResult clas : classifier.getClasses()) {
						// map.put(clas.getClassName().toString(), clas.getScore().toString());
						// logger.info("Class---->"+clas.getClassName());
						// logger.info("Class---->"+map);
					//	System.out.println("Name----->"+classifier.getName());
						System.out.println("Class: " + clas.getClassName().toString() + " Score" + clas.getScore().toString()+"    Hirearcy--->"+clas.getTypeHierarchy());
						ImageProcessorBean ipBean = new ImageProcessorBean();
						ipBean.data(clas.getClassName().toString(), clas.getScore().toString(), fileName.toString(),path.substring(43), new Date());
						imageInfo.add(ipBean);
						// imageInfo.add(arg0)
					}
				}
			}
		}
	}

	public void copyDirectory(File sourceLocation, File targetLocation) throws IOException {

		if (sourceLocation.isDirectory()) {
			if (!targetLocation.exists()) {
				targetLocation.mkdir();
			}

			String[] children = sourceLocation.list();
			for (int i = 0; i < children.length; i++) {
				copyDirectory(new File(sourceLocation, children[i]), new File(targetLocation, children[i]));
			}
		} else {

			InputStream in = new FileInputStream(sourceLocation);
			OutputStream out = new FileOutputStream(targetLocation);

			// Copy the bits from instream to outstream
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		}
	}

	public void deletAllFiles(File dir) {

		for (File file : dir.listFiles())
			if (!file.isDirectory())
				file.delete();
	}

//	@Override
//	public void execute(JobExecutionContext jobContext) throws JobExecutionException {
//
//		System.out.println("--------------------------------------------------------------------");
//		System.out.println("MyJob start: " + jobContext.getFireTime());
//		JobDetail jobDetail = jobContext.getJobDetail();
//		System.out.println("Example name is: " + jobDetail.getJobDataMap().getString("example"));
//		System.out.println("MyJob end: " + jobContext.getJobRunTime() + ", key: " + jobDetail.getKey());
//		System.out.println("MyJob next scheduled time: " + jobContext.getNextFireTime());
//		System.out.println("--------------------------------------------------------------------");
//
//		System.out.println("App Schedular Trigger Starts.." + new Date());
//
//		try {
//			System.out.println("App Schedular Trigger Starts.." + "intilaize()");
//			VisualRecognitionBean bean = new VisualRecognitionBean();
//			bean.intilaize();
//			String setEndPoint = bean.getSetEndPoint();
//			String apiKey = bean.getApiKey();
//			String filePath = bean.getFilePath();
//			String VisualRecognitionId = bean.getVisualRecognitionId();
//			String fileName = "fruitbowl.jpg";
//			System.out.println("App Schedular Trigger Starts.." + "Service Call Start...");
//			this.callService(setEndPoint, apiKey, filePath, VisualRecognitionId, fileName);
//			System.out.println("App Schedular Trigger Starts.." + "Service end ...");
//			// VisualRecognitionService.parseImageClassData(ci);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}

}
